let toggleBtn = document.getElementById("toggleBtn");
let containerNav = document.getElementById("containerNav");
let navList = document.querySelector(".nav ul");

function mobileMenu() {
    if(containerNav.style.height === "15vh") {
        containerNav.style.height = "55vh";
        toggleBtn.classList.add('toggle-btn-exit');
        navList.style.display = "block";
    }

    else {
      containerNav.style.height = "15vh";
      toggleBtn.classList.remove('toggle-btn-exit');
      navList.style.display = "none";
  }
}

toggleBtn.addEventListener('click', mobileMenu);


window.onscroll = function() {scrollEffect()};

function scrollEffect() {
  if (document.documentElement.scrollTop > 0) {
    document.getElementById("containerNav").style.height = "10vh";
    document.getElementById("navBar").style.height = "10vh";
  } else {
    document.getElementById("containerNav").style.height = "15vh";
    document.getElementById("navBar").style.height = "15vh";
  }
} 